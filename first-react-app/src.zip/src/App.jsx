import {Card} from "./components/card.jsx";

function App() {
    return <Card/>
}

export default App
